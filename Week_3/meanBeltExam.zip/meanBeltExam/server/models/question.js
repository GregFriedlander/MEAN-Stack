var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt-as-promised');

var UserSchema = new mongoose.Schema({
    first_name: String,
    last_name: String,
    email: String,
    password: String,
    questions: [{type: Schema.Types.ObjectId, ref: 'Question'}],
    answers: [{type: Schema.Types.ObjectId, ref: 'Answer'}]
}, {timestamps: true})

UserSchema.pre('save', function(next){
	var user = this;
	bcrypt.hash(user.password, 10)
	.then(function(hashed_pw){
		user.password = hashed_pw;
		next();
	})
	.catch(function(error){
		console.log(error);
	})
})

mongoose.model('User', UserSchema);

var QuestionSchema = new mongoose.Schema({
    content: String,
    description: String,
    answers: [{type: Schema.Types.ObjectId, ref: 'Answer'}],
    _user: {type: Schema.Types.ObjectId, ref:'User'},
}, {timestamps: true})

mongoose.model('Question', QuestionSchema);

var AnswerSchema = new mongoose.Schema({
    content: String,
    details: String,
    likes: {type: Number, default: 0},
    _user: {type: Schema.Types.ObjectId, ref:'User'},
    _question: {type: Schema.Types.ObjectId, ref:'Question'},
}, {timestamps: true})

mongoose.model('Answer', AnswerSchema);
