var mongoose = require('mongoose');
var User = mongoose.model('User');
var Question = mongoose.model('Question');
var Answer = mongoose.model('Answer');
var bcrypt = require('bcrypt-as-promised');

module.exports = {
    register: function(req,res){
        console.log('hit Users.register');
        console.log('the req.body = ', req.body);
        if(req.body.password != req.body.passwordConfirm){
            res.send('Passwords do not match');
        }else{
            var newUser = new User(req.body);
			newUser.save(function(err){
				if(err){
					console.log("something went wrong");
					console.log(err);
					var errorsArray = [];
					if(err.errmsg != undefined){
						errorsArray = [{message: "Email is already taken"}]
					}else{
						for(var key in err.errors){
							errorsArray.push(err.errors[key]);
						}
					}
					
					res.json(errorsArray);
				}else{
					console.log("successfully saved user");
                    req.session.userId = newUser._id;
                    req.session.userName = newUser.first_name;
					res.json(newUser);
				}
			})
        }
    },
    login: function(req,res){
        console.log('hit Users.login');
        console.log('the req.body = ', req.body);
        User.findOne({email:req.body.email}, function(err, foundUser){
			if(foundUser != null){
				console.log("found user in DB");
				// Verify the passwords using bcrypt
				bcrypt.compare(req.body.password, foundUser.password)
				.then(function(data){
					console.log("passwords match");
                    req.session.userId = foundUser._id;
                    req.session.userName = foundUser.first_name;
					res.json(foundUser);
					// Once logged in, add the user to session and redirect

				})
				.catch(function(error){
					console.log("passwords don't match");
					console.log(error);
					res.json(error);
				})
			}
		})
    },
    current: function(req,res){
        User.findOne({_id: req.session.userId}).exec(function(err, foundUser){
			console.log('foundUser', foundUser);
			res.json(foundUser);
		})
    },
    destroysession: function(req,res){
        console.log('hit Users.destroysession');
        req.session.destroy(function(){
            console.log('destroyed the session info');
            res.json(true);
        })
    },
    addquestion: function(req,res){
        console.log('hit Users.addquestion');
        console.log('the req.body = ', req.body);
        var newQuestion = new Question(req.body);
        newQuestion._user = req.session.userId;
        newQuestion.save(function(err){
            if(err){
                console.log('the new question DID NOT save');
            }else{
                console.log('the new question SAVED: ', newQuestion);
                res.send(true);
            }
        })
    },
    getquestions: function(req,res){
        console.log('hit Users.getquestions');
        Question.find({})
        .populate('answers')
        .exec(function(err,foundQuestions){
            if(err){
                console.log('something went wrong');
                res.json(err);
            }else{
                console.log('found the questions');
                res.json(foundQuestions);
            }
        })
    },
    getsinglequestion: function(req,res){
        console.log('hit Users.getSingleQuestion');
        console.log('the req.params.id = ', req.params.id);
        Question.findOne({_id: req.params.id})
        .populate('answers')
        .exec(function(err, foundQuestion){
            if(err){
                console.log('There was an error getting your listings');
                res.send(err);
            }else{
                res.json(foundQuestion);
            }
        })
    },
    addanswer: function(req,res){
        console.log('hit Users.addanswer');
        console.log('the question Id = ', req.params.questionid);
        Question.findOne({_id: req.params.questionid}, function(err,question){
            var newAnswer = new Answer(req.body);
            newAnswer._question = question._id;
            newAnswer._user = req.session.userId;
            newAnswer.save(function(err){
                question.answers.push(newAnswer);
                question.save(function(err){
                    if(err){
                        console.log('the new answer DID NOT save');
                        res.send(err);
                    }else{
                        console.log('the new answer SAVED: ', newAnswer);
                        res.send(true);
                    }
                })
            })
        })
    },
    updateanswer: function(req,res){
        console.log('hit Users.updateanswer');
        Answer.findOne({_id: req.params.id}, function(err,answer){
            if(err){
                console.log('something went wrong trying to update answer');
                res.send(err);
            }else{
                answer.likes ++;
                answer.save(function(err){
                    if(err){
                        console.log('did not save the updated answer');
                        res.send(err);
                    }else{
                        console.log('the updated answer was saved');
                        res.send(true);
                    }
                })
            }
        })
    }
}