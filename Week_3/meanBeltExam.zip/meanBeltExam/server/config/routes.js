var path = require('path');
var Users = require('./../controllers/questions.js');
var Questions = require('./../controllers/questions.js');
var Answers = require('./../controllers/questions.js');

module.exports = function(app){
    app.post('/adduser', Users.register);
    app.post('/login', Users.login);
    app.get('/current', Users.current);
    app.get('/destroysession', Users.destroysession);
    app.post('/addquestion/', Users.addquestion);
    app.get('/getquestions', Users.getquestions);
    app.get('/getsinglequestion/:id', Users.getsinglequestion);
    app.post('/addanswer/:questionid', Users.addanswer);
    app.post('/updateanswer/:id', Users.updateanswer);
    app.all("*", (req, res) => { res.sendFile(path.resolve("./public/dist/index.html")) });
}