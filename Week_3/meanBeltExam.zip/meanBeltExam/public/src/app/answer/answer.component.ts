import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionService } from './../question.service';
import { Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-answer',
  templateUrl: './answer.component.html',
  styleUrls: ['./answer.component.css']
})
export class AnswerComponent implements OnInit {

  question = {_id: ''};
  thisQuestion = {};

  constructor(private _questionService: QuestionService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._route.paramMap.subscribe((params)=>{
      console.log('the id of the question is: ', params.get('id'))
      this.question._id = params.get('id');
      this._questionService.getSingleQuestion(this.question._id)
      .subscribe((data:any)=>{
        console.log('getting the question, data =', data);
        this.thisQuestion = data;
      })
    })
  }

  clickedLogout(){
    this._questionService.destroySession()
    .subscribe((data)=>{
      console.log('logging out, redirecting');
      this._router.navigate(['']);
    })
  }

  increaseLike(answerId){
    this._questionService.updateAnswer(answerId)
    .subscribe((data: any)=>{
      console.log('getting response from increase like, data = ', data);
      this._questionService.getSingleQuestion(this.question._id)
      .subscribe((data:any)=>{
        console.log('getting the question, data =', data);
        this.thisQuestion = data;
      })
    })

  }

}
