import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionService } from './../question.service';

@Component({
  selector: 'app-new-question',
  templateUrl: './new-question.component.html',
  styleUrls: ['./new-question.component.css']
})
export class NewQuestionComponent implements OnInit {

  newQuestion: any = {content: '', description: ''};
  errors: any[] = [];

  constructor(private _questionService: QuestionService, private _router: Router) { }

  ngOnInit() {
  }
  onSubmit(){
    this._questionService.addQuestion(this.newQuestion)
    .subscribe((data:any)=>{
      console.log('submit new question got a response from server: ', data);
      if(data.errors != undefined){
        console.log('there were errors');
        this.errors = data;
      }else{
        console.log('posted a new question');
        this.newQuestion = {content: '', description: ''};
        this._router.navigate(['/dashboard']);
      }
    })
  }

  clickedLogout(){
    this._questionService.destroySession()
    .subscribe((data)=>{
      console.log('logging out, redirecting');
      this._router.navigate(['']);
    })
  }

}
