import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class QuestionService {

  constructor(private _http: HttpClient) { }

  addUser(userObj){
    return this._http.post('/adduser', userObj);
  }
  loginUser(userObj){
    return this._http.post('/login', userObj);
  }
  getCurrentUser(){
    return this._http.get('/current');
  }
  destroySession(){
    return this._http.get('/destroysession');
  }
  addQuestion(questionObj){
    return this._http.post('/addquestion', questionObj);
  }
  getQuestions(){
    return this._http.get('/getquestions');
  }
  getSingleQuestion(questionId){
    return this._http.get('/getsinglequestion/'+questionId);
  }
  addAnswer(answerObj, questionId){
    return this._http.post('/addanswer/' + questionId, answerObj);
  }
  updateAnswer(answerObj){
    return this._http.post('/updateanswer/'+answerObj, answerObj);
  }

}
