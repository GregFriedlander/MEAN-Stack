import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionService } from './../question.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-answer',
  templateUrl: './new-answer.component.html',
  styleUrls: ['./new-answer.component.css']
})
export class NewAnswerComponent implements OnInit {

  question = {_id: ''};
  thisQuestion = {};
  newAnswer: any = {content: '', details: ''};
  errors: any[] = [];

  constructor(private _questionService: QuestionService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._route.paramMap.subscribe((params)=>{
      console.log('the id of the question is: ', params.get('id'))
      this.question._id = params.get('id');
      this._questionService.getSingleQuestion(this.question._id)
      .subscribe((data:any)=>{
        console.log('getting the questions, data =', data);
        this.thisQuestion = data;
      })
    })
  }

  onSubmit(){
    this._questionService.addAnswer(this.newAnswer, this.question._id)
    .subscribe((data:any)=>{
      console.log('submit new answer got a response from server: ', data);
      if(data.errors != undefined){
        console.log('there were errors');
        this.errors = data;
      }else{
        console.log('posted a new answer');
        this.newAnswer = {content: '', description: ''};
        this._router.navigate(['/question',this.question._id]);
      }
    })
  }

  clickedLogout(){
    this._questionService.destroySession()
    .subscribe((data)=>{
      console.log('logging out, redirecting');
      this._router.navigate(['']);
    })
  }

}
