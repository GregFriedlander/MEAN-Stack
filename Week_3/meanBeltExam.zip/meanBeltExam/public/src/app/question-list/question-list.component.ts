import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionService } from './../question.service';

@Component({
  selector: 'app-question-list',
  templateUrl: './question-list.component.html',
  styleUrls: ['./question-list.component.css']
})
export class QuestionListComponent implements OnInit {

  currentUser: any = {};
  allQuestions: any = [{}];
  shownQuestions: any = [{}];
  searchTerm: string = '';

  constructor(private _questionService: QuestionService, private _router: Router) { }

  ngOnInit() {
    this._questionService.getCurrentUser()
  	.subscribe((data)=>{
  		console.log("got current user from db:", data);
      this.currentUser = data;
      this._questionService.getQuestions()
      .subscribe((data:any)=>{
        console.log('getting all the questions, data = ', data);
        this.allQuestions = data;
        this.shownQuestions = data;
      })
  	})
  }

  clickedLogout(){
    this._questionService.destroySession()
    .subscribe((data)=>{
      console.log('logging out, redirecting');
      this._router.navigate(['']);
    })
  }

  searchListings(searchTerm){
    this.shownQuestions = this.allQuestions.filter(function(listing){
      return listing.content.toLowerCase().includes(searchTerm.toLowerCase());
    })
  }

}
